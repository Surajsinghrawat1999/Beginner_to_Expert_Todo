todos = []
while True :
    user = input("Enter the items to be added in the list : ")
    todos.append(user)
    print(todos)