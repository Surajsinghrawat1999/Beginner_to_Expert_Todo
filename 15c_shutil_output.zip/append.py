countries = []
while True:

    country = input("Enter the country: ")
    countries.append(country)
    print(countries)
