list1 = ["Ram", "Shyam", "Sunder" ,"Manish", "Byomkesh" , "Avadhut"]
list1.sort()
for index,item in enumerate(list1):
    print(f"{index + 1}-{item}")
