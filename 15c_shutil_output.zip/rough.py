ranking = ['John', 'Sen', 'Lisa']

name = input("Enter a name:")
oil = ranking.index()
print(oil)
