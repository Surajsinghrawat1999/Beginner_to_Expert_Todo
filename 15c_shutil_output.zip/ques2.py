# Create a program that prompts the user to input their name repeatedly.
# Then, the program repeatedly prints out the name with the first letter capitalized.


while True :
    ask = input("Please enter your name : ")
    print(ask.capitalize())